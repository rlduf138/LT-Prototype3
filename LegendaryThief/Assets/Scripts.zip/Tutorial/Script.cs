﻿using PixelSilo.Helper;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Script : Singleton<Script>
{

      [Header("Tutorial")]
      public string[] text_list;
      public int[] portrait_number;
      public Sprite[] ilust_list;
      public string[] name_list;
     
}
